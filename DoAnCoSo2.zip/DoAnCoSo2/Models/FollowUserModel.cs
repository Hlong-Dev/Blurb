﻿namespace DoAnCoSo2.Models
{
    public class FollowUserModel
    {
        public string FollowerId { get; set; }
        public string FolloweeId { get; set; }
    }
}
