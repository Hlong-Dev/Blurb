﻿namespace DoAnCoSo2.Models
{
    public class UserProfileModel
    {
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string AvatarUrl { get; set; }
        // Thêm các thông tin khác tùy vào yêu cầu của bạn
    }
}
