﻿namespace DoAnCoSo2.Models
{
    public class UserModel
    {
    }
}
