﻿namespace DoAnCoSo2.Models
{
    public class UnfollowUserModel
    {
        public string FollowerId { get; set; }
        public string FolloweeId { get; set; }
    }
}